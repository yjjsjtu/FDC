// Copyright 2023-2024 fdcanusb contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <cstdint>
#include <cstdio>
#include "mbed.h"
#include "fw/millisecond_timer.h"
#include "fw/font_arial.h"

namespace fw {

class ST7735 {
 public:
  struct Options {
    // DC, RES, CS as manual GPIOs
    GPIO_TypeDef* dc_port = nullptr;
    uint16_t dc_pin = 0;
    GPIO_TypeDef* res_port = nullptr;
    uint16_t res_pin = 0;
    GPIO_TypeDef* cs_port = nullptr;
    uint16_t cs_pin = 0;

    MillisecondTimer* timer = nullptr;
  };

  explicit ST7735(const Options& opts)
      : opts_(opts), timer_(*opts.timer) {
    InitGpio();
    InitDisplay();
    InitUI();
  }

  /// Call periodically (e.g., every 100ms). Updates ONE row of numbers
  /// per call, cycling U->I->P->U... to minimize blocking time.
  void DisplayPower(int32_t voltage_mv, int32_t current_ma) {
    int32_t power_mw = static_cast<int32_t>(
        (static_cast<int64_t>(voltage_mv) * current_ma) / 1000);

    char val[16];
    if (update_row_ == 0) {
      FormatValue(val, sizeof(val), voltage_mv);
      FillRect(COL_OFFSET, ROW_Y[0], 100, 24, BG_COLOR);
      DrawStringBold(COL_OFFSET, ROW_Y[0], val, COLOR_U, BG_COLOR);
    } else if (update_row_ == 1) {
      FormatValue(val, sizeof(val), current_ma);
      FillRect(COL_OFFSET, ROW_Y[1], 100, 24, BG_COLOR);
      DrawStringBold(COL_OFFSET, ROW_Y[1], val, COLOR_I, BG_COLOR);
    } else {
      FormatValue(val, sizeof(val), power_mw);
      FillRect(COL_OFFSET, ROW_Y[2], 100, 24, BG_COLOR);
      DrawStringBold(COL_OFFSET, ROW_Y[2], val, COLOR_P, BG_COLOR);
    }

    update_row_++;
    if (update_row_ >= 3) {
      update_row_ = 0;
    }
  }

 private:
  static constexpr uint16_t WIDTH = 160;
  static constexpr uint16_t HEIGHT = 80;

  // Layout constants
  static constexpr uint16_t ROW_Y[3] = {6, 32, 58};
  static constexpr uint16_t BADGE_X = 4;
  static constexpr uint16_t BADGE_W = 16;
  static constexpr uint16_t BADGE_H = 16;
  static constexpr uint16_t BADGE_R = 4;

  static constexpr uint16_t COL_OFFSET = BADGE_X + BADGE_W + 8;
  static constexpr uint16_t UNIT_X = WIDTH - 20;
  static constexpr uint16_t BAR_X = WIDTH - 6;
  static constexpr uint16_t BAR_W = 4;

  // Colors (RGB565)
  static constexpr uint16_t BG_COLOR = 0x0000;  // Black
  static constexpr uint16_t COLOR_U  = 0xF800;  // Red
  static constexpr uint16_t COLOR_I  = 0x07E0;  // Green
  static constexpr uint16_t COLOR_P  = 0x001F;  // Blue

  // ST7735 internal XY offsets (160x80, landscape)
  static constexpr uint16_t X_OFFSET = 1;
  static constexpr uint16_t Y_OFFSET = 26;

  // Draw all static UI elements (called once from constructor)
  void InitUI() {
    static constexpr uint16_t ROW_COLORS[3] = {COLOR_U, COLOR_I, COLOR_P};
    static constexpr char BADGE_LABELS[3] = {'U', 'I', 'P'};
    static constexpr char UNIT_LABELS[3]  = {'V', 'A', 'W'};

    for (int i = 0; i < 3; i++) {
      // Badge (rounded rect + label)
      FillRoundRect(BADGE_X, ROW_Y[i], BADGE_W, BADGE_H, BADGE_R, ROW_COLORS[i]);
      DrawCharBold(BADGE_X + 2, ROW_Y[i] + 1, BADGE_LABELS[i],
                   BG_COLOR, ROW_COLORS[i], 12, 18);

      // Unit letter (right before bar)
      DrawCharBold(UNIT_X, ROW_Y[i] + 4, UNIT_LABELS[i],
                   ROW_COLORS[i], BG_COLOR, 12, 18);

      // Colored vertical bar
      FillRect(BAR_X, ROW_Y[i], BAR_W, BADGE_H, ROW_COLORS[i]);
    }
  }

  // Format a milli-unit value (e.g., mV, mA, mW) into "xx.x" string
  void FormatValue(char* buf, int buf_size, int32_t milli_val) {
    int32_t integer = milli_val / 1000;
    int32_t frac = (milli_val % 1000) / 100;
    if (frac < 0) frac = -frac;
    snprintf(buf, buf_size, "%ld.%ld", (long)integer, (long)frac);
  }

  // Fill a rectangular area with a solid color via HW SPI
  void FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h,
                uint16_t color) {
    if (w == 0 || h == 0) return;
    SetWindow(x, y, x + w - 1, y + h - 1);
    DcHigh();
    CsLow();
    uint8_t hi = color >> 8;
    uint8_t lo = color & 0xFF;
    for (uint32_t i = 0; i < (uint32_t)w * h; i++) {
      SpiByte(hi);
      SpiByte(lo);
    }
    SpiWaitDone();
    CsHigh();
  }

  // Fill a rounded rectangle (radius r at corners)
  void FillRoundRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h,
                     uint16_t r, uint16_t color) {
    if (r > w / 2) r = w / 2;
    if (r > h / 2) r = h / 2;

    FillRect(x, y + r, w, h - 2 * r, color);
    FillRect(x + r, y, w - 2 * r, r, color);
    FillRect(x + r, y + h - r, w - 2 * r, r, color);

    FillCorner(x + r,         y + r,         r, color, -1, -1);
    FillCorner(x + w - r - 1, y + r,         r, color, +1, -1);
    FillCorner(x + r,         y + h - r - 1, r, color, -1, +1);
    FillCorner(x + w - r - 1, y + h - r - 1, r, color, +1, +1);
  }

  // Fill a quarter-circle corner area
  void FillCorner(int16_t cx, int16_t cy, uint16_t r,
                  uint16_t color, int8_t dx_dir, int8_t dy_dir) {
    for (int16_t dy = 0; dy <= (int16_t)r; dy++) {
      for (int16_t dx = 0; dx <= (int16_t)r; dx++) {
        if (dx * dx + dy * dy <= (int16_t)(r * r)) {
          int16_t px = cx + dx * dx_dir;
          int16_t py = cy + dy * dy_dir;
          if (px >= 0 && px < (int16_t)WIDTH &&
              py >= 0 && py < (int16_t)HEIGHT) {
            SetWindow(px, py, px, py);
            DcHigh();
            CsLow();
            SpiByte(color >> 8);
            SpiByte(color & 0xFF);
            SpiWaitDone();
            CsHigh();
          }
        }
      }
    }
  }

  void InitGpio() {
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    // DC, RES, CS as standard GPIO output
    GPIO_InitTypeDef gpio = {};
    gpio.Mode = GPIO_MODE_OUTPUT_PP;
    gpio.Pull = GPIO_NOPULL;
    gpio.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    gpio.Pin = opts_.dc_pin;   HAL_GPIO_Init(opts_.dc_port, &gpio);
    gpio.Pin = opts_.res_pin;  HAL_GPIO_Init(opts_.res_port, &gpio);
    gpio.Pin = opts_.cs_pin;   HAL_GPIO_Init(opts_.cs_port, &gpio);

    CsHigh();

    // SPI1 SCK (PA5) and MOSI (PA7) as Alternate Function 5
    gpio.Mode = GPIO_MODE_AF_PP;
    gpio.Pin = GPIO_PIN_5 | GPIO_PIN_7;
    gpio.Alternate = GPIO_AF5_SPI1;
    HAL_GPIO_Init(GPIOA, &gpio);
  }

  void InitSpi() {
    // Enable SPI1 clock (APB2)
    __HAL_RCC_SPI1_CLK_ENABLE();

    // Disable SPI1 before configuration
    SPI1->CR1 &= ~SPI_CR1_SPE;

    // Configure SPI1: Master, 8-bit, CPOL=0, CPHA=0, MSB first
    // 1-line bidirectional TX-only mode (no MISO needed)
    // Software NSS management, baud rate = fPCLK/16 (170MHz/16 = 10.6MHz)
    // ST7735 max SPI clock is ~15MHz, so /16 is safe
    SPI1->CR1 = SPI_CR1_MSTR      // Master mode
              | SPI_CR1_SSI        // Internal slave select
              | SPI_CR1_SSM        // Software slave management
              | SPI_CR1_BIDIMODE   // 1-line bidirectional mode
              | SPI_CR1_BIDIOE     // Output enable (transmit only)
              | (0x03 << SPI_CR1_BR_Pos);  // BR[2:0] = 011 = fPCLK/16

    // Data size = 8 bit
    SPI1->CR2 = (0x07 << SPI_CR2_DS_Pos);  // DS[3:0] = 0111 = 8-bit

    // Enable SPI1
    SPI1->CR1 |= SPI_CR1_SPE;
  }

  void InitDisplay() {
    InitSpi();

    // Hardware reset
    ResHigh();
    timer_.wait_ms(5);
    ResLow();
    timer_.wait_ms(20);
    ResHigh();
    timer_.wait_ms(150);

    SendCmd(0x01);        // SWRESET
    timer_.wait_ms(150);

    SendCmd(0x11);        // SLPOUT
    timer_.wait_ms(150);

    SendCmd(0xB1);        // FRMCTR1
    SendData(0x01);
    SendData(0x2C);
    SendData(0x2D);

    SendCmd(0xB4);        // INVCTR
    SendData(0x07);

    SendCmd(0xC0);        // PWCTR1
    SendData(0xA2);
    SendData(0x02);
    SendData(0x84);

    SendCmd(0xC1);        // PWCTR2
    SendData(0xC5);

    SendCmd(0xC2);        // PWCTR3
    SendData(0x0A);
    SendData(0x00);

    SendCmd(0xC5);        // VMCTR1
    SendData(0x0E);

    SendCmd(0x21);        // INVON (this panel needs inversion)

    SendCmd(0x3A);        // COLMOD
    SendData(0x05);       // 16-bit color

    SendCmd(0x36);        // MADCTL - landscape
    SendData(0x60);       // MX + MV

    SendCmd(0x29);        // DISPON
    timer_.wait_ms(150);

    FillScreen(BG_COLOR);
  }

  void SetWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
    SendCmd(0x2A);  // CASET
    SendData16(x0 + X_OFFSET);
    SendData16(x1 + X_OFFSET);
    SendCmd(0x2B);  // RASET
    SendData16(y0 + Y_OFFSET);
    SendData16(y1 + Y_OFFSET);
    SendCmd(0x2C);  // RAMWR
  }

  void FillScreen(uint16_t color) {
    SetWindow(0, 0, WIDTH - 1, HEIGHT - 1);
    DcHigh();
    CsLow();
    uint8_t hi = color >> 8;
    uint8_t lo = color & 0xFF;
    for (uint32_t i = 0; i < (uint32_t)WIDTH * HEIGHT; i++) {
      SpiByte(hi);
      SpiByte(lo);
    }
    SpiWaitDone();
    CsHigh();
  }

  // Bold+scaled character from 8x16 Arial font.
  void DrawCharBold(uint16_t x, uint16_t y, char c,
                    uint16_t fg, uint16_t bg,
                    uint8_t out_w, uint8_t out_h) {
    if (c < 0x20 || c > 0x5A) c = ' ';
    const uint8_t* glyph = font_arial::DATA[c - 0x20];
    SetWindow(x, y, x + out_w - 1, y + out_h - 1);
    DcHigh();
    CsLow();
    for (int row = 0; row < out_h; row++) {
      int sr = row * 16 / out_h;  // nearest-neighbor vertical scale
      uint8_t bits = glyph[sr];
      for (int col = 0; col < out_w; col++) {
        int sc = col * 8 / out_w;  // nearest-neighbor horizontal scale
        uint16_t clr = (bits & (0x80 >> sc)) ? fg : bg;
        SpiByte(clr >> 8);
        SpiByte(clr & 0xFF);
      }
    }
    SpiWaitDone();
    CsHigh();
  }

  // Default bold string: 16x24 chars, 18px advance
  void DrawStringBold(uint16_t x, uint16_t y, const char* str,
                      uint16_t fg, uint16_t bg) {
    while (*str) {
      DrawCharBold(x, y, *str, fg, bg, 16, 24);
      x += 18;  // 16px char + 2px gap
      str++;
    }
  }

  // --- Low-level SPI (bare-metal, no HAL SPI calls) ---

  __attribute__((always_inline)) inline void SpiByte(uint8_t byte) {
    // Wait until TX buffer is empty
    while (!(SPI1->SR & SPI_SR_TXE)) {}
    // Write data byte (8-bit access to DR for 8-bit frame)
    *((__IO uint8_t *)&SPI1->DR) = byte;
  }

  // Wait until SPI is completely idle (call before toggling CS/DC)
  inline void SpiWaitDone() {
    while (SPI1->SR & SPI_SR_BSY) {}
  }

  // SendCmd: DC=low, CS=low, send byte, CS=high
  void SendCmd(uint8_t cmd) {
    DcLow();
    CsLow();
    SpiByte(cmd);
    SpiWaitDone();
    CsHigh();
  }

  // SendData: DC=high, CS=low, send byte, CS=high
  void SendData(uint8_t data) {
    DcHigh();
    CsLow();
    SpiByte(data);
    SpiWaitDone();
    CsHigh();
  }

  void SendData16(uint16_t data) {
    DcHigh();
    CsLow();
    SpiByte(data >> 8);
    SpiByte(data & 0xFF);
    SpiWaitDone();
    CsHigh();
  }

  // GPIO via BSRR for speed
  void DcHigh()   { opts_.dc_port->BSRR = opts_.dc_pin; }
  void DcLow()    { opts_.dc_port->BSRR = (uint32_t)opts_.dc_pin << 16; }
  void ResHigh()  { opts_.res_port->BSRR = opts_.res_pin; }
  void ResLow()   { opts_.res_port->BSRR = (uint32_t)opts_.res_pin << 16; }
  void CsHigh()   { opts_.cs_port->BSRR = opts_.cs_pin; }
  void CsLow()    { opts_.cs_port->BSRR = (uint32_t)opts_.cs_pin << 16; }

  Options opts_;
  MillisecondTimer& timer_;
  uint8_t update_row_ = 0;  // cycles 0->1->2->0 for incremental updates
};

}  // namespace fw
