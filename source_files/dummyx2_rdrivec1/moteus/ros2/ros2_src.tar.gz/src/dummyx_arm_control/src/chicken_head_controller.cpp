/**
 * chicken_head_controller.cpp
 *
 * 六轴机械臂"鸡头效果"演示节点
 * ---------------------------------------------------
 * 效果：Joint1（基座）做 ±swing_angle 周期摆动，
 *       MoveIt2 通过逆运动学（IK）自动调整 J2-J6，
 *       使末端执行器 link6_1 的位置和姿态保持不动。
 *
 * 运行前提：MoveIt2 + usb2can_node 已启动
 *
 * 使用示例：
 *   ros2 run dummyx_arm_control chicken_head_controller
 *   ros2 run dummyx_arm_control chicken_head_controller \
 *       --ros-args -p swing_angle:=0.5 -p num_waypoints:=30 \
 *                  -p vel_scaling:=0.3 -p num_cycles:=3
 *
 * 编译注意：编译前需退出 conda 环境（conda deactivate）
 */

#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/robot_model/robot_model.h>
#include <moveit/robot_state/robot_state.h>
#include <moveit/robot_trajectory/robot_trajectory.h>
#include <moveit/trajectory_processing/time_optimal_trajectory_generation.h>
#include <moveit_msgs/msg/robot_trajectory.hpp>
#include <geometry_msgs/msg/pose.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <cmath>
#include <vector>
#include <string>

// ─── 常量 ────────────────────────────────────────────
static constexpr double ROBOT_MAX_ACCEL   = 2.513;  // rad/s²（来自 URDF joint_limits）
static constexpr double TOTG_DEFAULT_ACCEL = 1.0;   // TOTG 默认加速度上限

// ─── 辅助：将 J1 摆动序列（弧度）生成为 std::vector ──
//   生成结构：0 → +swing → −swing → 0，共 num_waypoints 段
static std::vector<double> make_j1_sequence(double swing, int n_half)
{
    std::vector<double> seq;
    seq.reserve(static_cast<size_t>(n_half) * 4 + 1);

    // 段1: 0 → +swing
    for (int i = 0; i <= n_half; ++i) {
        seq.push_back(swing * static_cast<double>(i) / n_half);
    }
    // 段2: +swing → −swing
    for (int i = 1; i <= 2 * n_half; ++i) {
        seq.push_back(swing - 2.0 * swing * static_cast<double>(i) / (2 * n_half));
    }
    // 段3: −swing → 0
    for (int i = 1; i <= n_half; ++i) {
        seq.push_back(-swing + swing * static_cast<double>(i) / n_half);
    }
    return seq;
}

int main(int argc, char *argv[])
{
    // ─── 1. ROS2 初始化 ───────────────────────────────
    rclcpp::init(argc, argv);
    auto node = rclcpp::Node::make_shared("dummyx_chicken_head_node");
    auto logger = node->get_logger();
    RCLCPP_INFO(logger, "====== 鸡头效果控制节点已启动 ======");

    // ─── 2. 声明可配置参数 ──────────────────────────────
    node->declare_parameter("swing_angle",   0.5);   // J1 摆动幅度 [rad]，约 28.6°
    node->declare_parameter("num_waypoints", 30);    // 单次完整摆动的路点数（每段1/4 ≈ 7-8个）
    node->declare_parameter("vel_scaling",   0.3);   // 速度缩放
    node->declare_parameter("acc_scaling",   0.2);   // 加速度缩放
    node->declare_parameter("num_cycles",    3);     // 摆动循环次数

    const double swing_angle   = node->get_parameter("swing_angle").as_double();
    const int    num_waypoints = node->get_parameter("num_waypoints").as_int();
    const double vel_scaling   = node->get_parameter("vel_scaling").as_double();
    const double acc_scaling   = node->get_parameter("acc_scaling").as_double();
    const int    num_cycles    = node->get_parameter("num_cycles").as_int();

    // TOTG 加速度缩放补偿（与 circle_controller 保持一致）
    const double acc_scaling_totg = std::min(1.0, acc_scaling * (ROBOT_MAX_ACCEL / TOTG_DEFAULT_ACCEL));

    RCLCPP_INFO(logger,
        "参数: swing_angle=%.3f rad (%.1f°), num_waypoints=%d, "
        "vel_scaling=%.2f, acc_scaling=%.2f (TOTG补偿=%.3f), num_cycles=%d",
        swing_angle, swing_angle * 180.0 / M_PI,
        num_waypoints, vel_scaling, acc_scaling, acc_scaling_totg, num_cycles);

    // ─── 3. MoveGroupInterface 初始化 ───────────────────
    moveit::planning_interface::MoveGroupInterface move_group(node, "dummyx2_arm");
    move_group.setPlanningTime(30.0);
    move_group.setMaxVelocityScalingFactor(vel_scaling);
    move_group.setMaxAccelerationScalingFactor(acc_scaling);

    const std::string ee_link = "link6_1";
    move_group.setEndEffectorLink(ee_link);

    RCLCPP_INFO(logger, "MoveGroupInterface 已创建，末端链接：%s", ee_link.c_str());

    // ─── 4. 移动到 home 位姿（安全起始点）──────────────
    RCLCPP_INFO(logger, "正在移动到 home 位姿...");
    move_group.setNamedTarget("home");
    moveit::planning_interface::MoveGroupInterface::Plan home_plan;
    bool home_ok = (move_group.plan(home_plan) == moveit::core::MoveItErrorCode::SUCCESS);
    if (home_ok) {
        move_group.execute(home_plan);
        RCLCPP_INFO(logger, "已到达 home 位姿");
    } else {
        RCLCPP_ERROR(logger, "无法规划到 home 位姿，请检查机械臂状态！");
        rclcpp::shutdown();
        return 1;
    }

    // 等待状态稳定
    rclcpp::sleep_for(std::chrono::milliseconds(500));

    // ─── 5. 获取并锁定末端位姿（这是整个过程的固定目标）──
    geometry_msgs::msg::PoseStamped ee_stamped = move_group.getCurrentPose(ee_link);
    geometry_msgs::msg::Pose fixed_ee_pose = ee_stamped.pose;

    RCLCPP_INFO(logger,
        "末端固定位姿（鸡头锁定点）: pos=(%.4f, %.4f, %.4f), "
        "quat=(%.4f, %.4f, %.4f, %.4f)",
        fixed_ee_pose.position.x,
        fixed_ee_pose.position.y,
        fixed_ee_pose.position.z,
        fixed_ee_pose.orientation.x,
        fixed_ee_pose.orientation.y,
        fixed_ee_pose.orientation.z,
        fixed_ee_pose.orientation.w);

    // ─── 6. 获取机器人模型与关节组 ─────────────────────
    const auto robot_model = move_group.getRobotModel();
    const auto jmg = robot_model->getJointModelGroup("dummyx2_arm");
    if (!jmg) {
        RCLCPP_ERROR(logger, "找不到关节组 'dummyx2_arm'！");
        rclcpp::shutdown();
        return 1;
    }

    // ─── 7. 生成每个 cycle 的摆动路点（IK 求解）──────────
    // n_half: 每个 1/4 摆动段的步数
    const int n_half = std::max(5, num_waypoints / 4);

    RCLCPP_INFO(logger, "开始执行 %d 次鸡头摆动（每次完整摆动 %d 个路点）",
                num_cycles, n_half * 4 + 1);

    for (int cycle = 0; cycle < num_cycles; ++cycle) {
        RCLCPP_INFO(logger, "── 第 %d/%d 次摆动 ──", cycle + 1, num_cycles);

        // 生成 J1 角度序列（0 → +swing → −swing → 0）
        std::vector<double> j1_sequence = make_j1_sequence(swing_angle, n_half);

        // 用"热启动"状态（上一个路点状态）提高 IK 连续性
        auto seed_state = std::make_shared<moveit::core::RobotState>(robot_model);
        seed_state->setToDefaultValues();
        // 用当前实际关节状态初始化（更接近实际位置）
        {
            std::vector<double> current_joints;
            move_group.getCurrentState()->copyJointGroupPositions(jmg, current_joints);
            seed_state->setJointGroupPositions(jmg, current_joints);
            seed_state->update();
        }

        // 构建 RobotTrajectory 路点列表
        robot_trajectory::RobotTrajectory rt(robot_model, "dummyx2_arm");
        int ik_success_count = 0;
        int ik_fail_count = 0;

        for (size_t i = 0; i < j1_sequence.size(); ++i) {
            double j1_angle = j1_sequence[i];

            // 设置 J1 初值提示（热启动）
            seed_state->setJointPositions("Joint1", &j1_angle);
            seed_state->update();

            // 在当前 seed_state 基础上，对末端固定位姿求 IK
            bool found = seed_state->setFromIK(
                jmg,
                fixed_ee_pose,
                ee_link,
                0.1  /* IK timeout 秒 */
            );

            if (found) {
                // setFromIK 会自由调整所有关节，可能改变 J1
                // 强制覆盖 J1 到目标角度（保证底座确实在摆动）
                seed_state->setJointPositions("Joint1", &j1_angle);
                seed_state->update();

                // 添加路点（时间戳 0，由 TOTG 后处理赋时）
                rt.addSuffixWayPoint(*seed_state, 0.0);
                ++ik_success_count;
            } else {
                RCLCPP_WARN(logger,
                    "路点 %zu (J1=%.3f rad) IK 求解失败，跳过此点",
                    i, j1_angle);
                ++ik_fail_count;
            }
        }

        RCLCPP_INFO(logger,
            "IK 求解结果：成功=%d, 失败=%d (成功率=%.1f%%)",
            ik_success_count, ik_fail_count,
            100.0 * ik_success_count / (ik_success_count + ik_fail_count + 1e-9));

        if (rt.getWayPointCount() < 2) {
            RCLCPP_ERROR(logger, "路点数不足（%zu），跳过本次摆动", rt.getWayPointCount());
            continue;
        }

        // ─── 8. TOTG 时间参数化 ──────────────────────────
        //   resample_dt=0.025s（40Hz），与 circle_controller 保持一致
        trajectory_processing::TimeOptimalTrajectoryGeneration totg(0.025, 0.001);
        bool time_ok = totg.computeTimeStamps(rt, vel_scaling, acc_scaling_totg);

        if (!time_ok) {
            RCLCPP_WARN(logger, "TOTG 时间参数化失败，将以全速执行");
        } else {
            double duration = 0.0;
            if (rt.getWayPointCount() > 0) {
                duration = rt.getWayPointDurationFromStart(rt.getWayPointCount() - 1);
            }
            RCLCPP_INFO(logger,
                "TOTG 参数化成功：路点数=%zu，预计时长=%.2f 秒",
                rt.getWayPointCount(), duration);
        }

        // ─── 9. 将 RobotTrajectory 转为 Plan 并执行 ───────
        moveit_msgs::msg::RobotTrajectory traj_msg;
        rt.getRobotTrajectoryMsg(traj_msg);

        moveit::planning_interface::MoveGroupInterface::Plan exec_plan;
        exec_plan.trajectory_ = traj_msg;

        RCLCPP_INFO(logger, "开始执行第 %d 次鸡头摆动轨迹...", cycle + 1);
        auto exec_result = move_group.execute(exec_plan);
        if (exec_result == moveit::core::MoveItErrorCode::SUCCESS) {
            RCLCPP_INFO(logger, "第 %d 次摆动执行完成 ✓", cycle + 1);
        } else {
            RCLCPP_WARN(logger, "第 %d 次摆动执行返回非成功状态（code=%d）",
                        cycle + 1, exec_result.val);
        }

        // 每次摆动之间短暂停顿（可选）
        if (cycle < num_cycles - 1) {
            rclcpp::sleep_for(std::chrono::milliseconds(300));
        }
    }

    // ─── 10. 返回 home 位姿 ──────────────────────────────
    RCLCPP_INFO(logger, "鸡头效果演示完成，3秒后返回 home 位姿...");
    rclcpp::sleep_for(std::chrono::seconds(3));

    move_group.setNamedTarget("home");
    moveit::planning_interface::MoveGroupInterface::Plan return_plan;
    bool ret_ok = (move_group.plan(return_plan) == moveit::core::MoveItErrorCode::SUCCESS);
    if (ret_ok) {
        move_group.execute(return_plan);
        RCLCPP_INFO(logger, "已返回 home 位姿");
    } else {
        RCLCPP_WARN(logger, "返回 home 规划失败，请手动复位");
    }

    // ─── 11. 关闭节点 ────────────────────────────────────
    RCLCPP_INFO(logger, "====== 鸡头效果控制节点执行完毕 ======");
    rclcpp::shutdown();
    return 0;
}
