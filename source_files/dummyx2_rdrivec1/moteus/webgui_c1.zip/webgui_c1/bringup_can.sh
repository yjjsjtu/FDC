#!/bin/sh
#!/bin/bash

# First check if can0 interface already exists
if ip link show can0 >/dev/null 2>&1; then
    sleep 1
    sudo ip link set can0 type can bitrate 1000000
    sudo ip link set can0 txqueuelen 1000
    sudo ip link set can0 up
    echo "can0 interface configured and enabled."
    exit 0
fi

# Check if /dev/usb2can exists (higher priority)
if [ -e "/dev/usb2can" ]; then
    echo "Found dedicated device /dev/usb2can, starting slcand..."
    if sudo slcand -o -c -s0 /dev/usb2can can0; then
        sleep 1
        sudo ip link set can0 type can bitrate 1000000
        sudo ip link set can0 txqueuelen 1000
        sudo ip link set can0 up
        echo "can0 interface configured and enabled using /dev/usb2can."
        exit 0
    else
        echo "Warning: Failed to configure /dev/usb2can, trying other devices..."
    fi
fi

# Check all ttyACM* devices
echo "Scanning for available ttyACM devices..."
for device in /dev/ttyACM*; do
    # Skip if wildcard expansion failed
    if [ ! -e "$device" ]; then
        continue
    fi
    
    echo "Attempting to use device: $device"
    if sudo slcand -o -c -s0 "$device" can0; then
        sleep 1
        sudo ip link set can0 type can bitrate 1000000
        sudo ip link set can0 txqueuelen 1000
        sudo ip link set can0 up
        echo "Success: can0 interface configured and enabled using $device."
        exit 0
    else
        echo "Device $device configuration failed, trying next..."
        # Clean up any partial configuration
        sudo slcand -c "$device" 2>/dev/null
    fi
done

# If no CAN devices found, exit with error
echo "Error: No available CAN devices found or all devices failed configuration."
echo "Please check:"
echo "1. USB-to-CAN adapter is properly connected"
echo "2. Drivers are installed"
echo "3. Current user has permission to access devices (may need to add user to dialout group)"
echo ""
echo "Detected devices:"
ls /dev/ttyACM* 2>/dev/null || echo "No ttyACM devices found"
ls /dev/usb2can 2>/dev/null || echo "/dev/usb2can device not found"
exit 1

